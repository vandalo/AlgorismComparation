COMPILAR algoritmos:
make


Compilar generador de juegos de prueba
g++ main.cpp -std=c++0x


EJECUTAR algoritmos:
test1 < cinpruebas
o también:
test1
Pregunta cuantos test quieres hacer:
indicas número de tests
ahora escribes los números uno a uno de que tests quieres ejecutar
(por ejemplo: el 2 y el 3)
2 3
Ahora el programa buscará los archivos dic2.txt + text2.txt y dic3.txt + text3.txt


Ejecutar generador de juegos de prueba:
a.out
Indicas el número de juegos de prueba que quieres generar
Indicas cuantas keys quieres que tenga
Indicas cuantos valores quieres que tenga el text.



